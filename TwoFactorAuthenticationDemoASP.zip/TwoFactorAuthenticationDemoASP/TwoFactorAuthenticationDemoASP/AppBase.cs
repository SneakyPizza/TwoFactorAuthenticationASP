﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;

namespace TwoFactorAuthenticationDemoASP
{
    class AppBase
    {
        public static SqlConnection CONNSTRING = new SqlConnection(ConfigurationManager.ConnectionStrings["DB"].ConnectionString);

    }
}
